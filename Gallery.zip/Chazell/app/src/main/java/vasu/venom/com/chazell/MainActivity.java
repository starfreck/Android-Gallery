package vasu.venom.com.chazell;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView  txt;
    ImageView img;
    Button previous;
    Button next;
    public int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt =(TextView) findViewById(R.id.txt);
        img =(ImageView) findViewById(R.id.img);
        previous = (Button) findViewById(R.id.previous);
        next = (Button) findViewById(R.id.next);



        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=count-1;
                counter();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=count+1;
                counter();
            }
        });

        counter();
    }

    public void counter(){

        if(count==0)
        {
            img.setImageResource(R.drawable.zero);
            txt.setText("Hey Welcome...");
            previous.setVisibility(View.INVISIBLE);
            next.setVisibility(View.VISIBLE);
        }else if(count==1) {
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.one);
            txt.setText("Beautiful...");

        }else if (count==2){
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.two);
            txt.setText("Admirable...");
        }else if (count==3){
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.three);
            txt.setText("Angelic...");
        }else if (count==4){
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.four);
            txt.setText("Beauteous...");
        }else if (count==5){
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.five);
            txt.setText("Lovable...");
        }else if (count==6){
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.six);
            txt.setText("Delightful...");
        }else if (count==7){
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.seven);
            txt.setText("Bewitching...");
        }else if (count==8){
            previous.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.eight);
            txt.setText("Alluring...");
        }else if (count==9){
            img.setImageResource(R.drawable.nine);
            txt.setText("Dreaming...");
            next.setVisibility(View.INVISIBLE);
        }

    }
}
